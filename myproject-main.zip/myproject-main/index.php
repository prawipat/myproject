<html>
    <head>
        <script>
                alert("Hi");
        </script>
    </head>
    <body>
        <?php
        echo "Hello World";
        ?>
    </body>
</html>